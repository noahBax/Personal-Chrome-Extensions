/**
 * 9.16.2023
 * The old code (mostly commented) was feeling a bit too flashy, I did this instead
 */
const ele = document.querySelector("body > div.content > div.applogin-banner > div.applogin-container > p");
if (ele)
	ele.textContent = "If you can read this, you don't need glasses";
